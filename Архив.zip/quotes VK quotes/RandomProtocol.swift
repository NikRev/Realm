import Foundation

protocol RandomLoadDelegate: AnyObject {
    func didAddQuote(_ quote: String)
}

